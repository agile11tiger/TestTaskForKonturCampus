﻿using System.Collections;
using System.Collections.Generic;

namespace ToDoList
{
    public class ToDoList : IToDoList
    {
        public void AddEntry(int entryId, int userId, string name, long timestamp)
        {
            throw new System.NotImplementedException();
        }

        public void RemoveEntry(int entryId, int userId, long timestamp)
        {
            throw new System.NotImplementedException();
        }

        public void MarkDone(int entryId, int userId, long timestamp)
        {
            throw new System.NotImplementedException();
        }

        public void MarkUndone(int entryId, int userId, long timestamp)
        {
            throw new System.NotImplementedException();
        }

        public void DismissUser(int userId)
        {
            throw new System.NotImplementedException();
        }

        public void AllowUser(int userId)
        {
            throw new System.NotImplementedException();
        }

        public IEnumerator<Entry> GetEnumerator()
        {
            throw new System.NotImplementedException();
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }

        public int Count { get; }
    }
}