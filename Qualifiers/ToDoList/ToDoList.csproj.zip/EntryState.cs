﻿namespace ToDoList
{
    public enum EntryState
    {
        Undone,
        Done
    }
}