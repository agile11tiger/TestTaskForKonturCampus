﻿namespace CommandLineCalculator
{
    public abstract class Interpreter
    {
        public abstract void Run(UserConsole userConsole, Storage storage);
    }
}