﻿using System;

namespace CommandLineCalculator
{
    public sealed class StatefulInterpreter : Interpreter
    {
        public override void Run(UserConsole userConsole, Storage storage)
        {
            throw new NotImplementedException();
        }
    }
}