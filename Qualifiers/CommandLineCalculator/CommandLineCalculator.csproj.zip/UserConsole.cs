﻿namespace CommandLineCalculator
{
    public abstract class UserConsole
    {
        public abstract string ReadLine();
        public abstract void WriteLine(string content);
    }
}